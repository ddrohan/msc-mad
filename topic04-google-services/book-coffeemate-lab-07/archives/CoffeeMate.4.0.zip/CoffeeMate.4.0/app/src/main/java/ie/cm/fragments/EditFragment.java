package ie.cm.fragments;

import android.content.Context;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import ie.cm.R;
import ie.cm.activities.Base;
import ie.cm.models.Coffee;

public class EditFragment extends Fragment {

    TextView titleBar;
    Coffee aCoffee;
    Boolean isFavourite;

    EditText    name, shop, price;
    RatingBar   ratingBar;
    ImageView   favouriteImage;

    private OnFragmentInteractionListener mListener;

    public EditFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static EditFragment newInstance(Bundle coffeeBundle) {
        EditFragment fragment = new EditFragment();
        fragment.setArguments(coffeeBundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getArguments() != null)
            aCoffee = getCoffeeObject(getArguments().getInt("coffeeID"));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_edit, container, false);

        ((TextView)v.findViewById(R.id.coffeeNameTextView)).setText(aCoffee.name);
        ((TextView)v.findViewById(R.id.coffeeShopTextView)).setText(aCoffee.shop);

        name = (EditText)v.findViewById(R.id.nameEditText);
        name.setText(aCoffee.name);

        shop = (EditText)v.findViewById(R.id.shopEditText);
        shop.setText(aCoffee.shop);

        price = (EditText)v.findViewById(R.id.priceEditText);
        price.setText(""+aCoffee.price);

        ratingBar = (RatingBar) v.findViewById(R.id.coffeeRatingBar);
        ratingBar.setRating((float)aCoffee.rating);

        favouriteImage = (ImageView) v.findViewById(R.id.favouriteImageView);

        if (aCoffee.favourite == true) {
            favouriteImage.setImageResource(R.drawable.ic_favourite_on);
            isFavourite = true;
        } else {
            favouriteImage.setImageResource(R.drawable.ic_favourite_off);
            isFavourite = false;
        }

        return v;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onResume() {
        super.onResume();

        titleBar = (TextView) getActivity().findViewById(R.id.recentAddedBarTextView);
        titleBar.setText(R.string.updateACoffeeLbl);
    }
    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        void toggle(View v);
        void update(View v);
    }

    private Coffee getCoffeeObject(int id) {

        for (Coffee c : Base.app.dbManager.getAll())
            if (c.coffeeId == id)
                return c;

        return null;
    }

    public void toggle(View v) {

        if (mListener != null) {
            String s = null;

            if (isFavourite) {
                aCoffee.favourite = false;
                s = "Removed From Favourites";
                isFavourite = false;
                favouriteImage.setImageResource(R.drawable.ic_favourite_off);
            } else {
                aCoffee.favourite = true;
                s = "Added to Favourites !!";
                isFavourite = true;
                favouriteImage.setImageResource(R.drawable.ic_favourite_on);
            }
            Toast.makeText(getActivity(), s, Toast.LENGTH_SHORT).show();
        }
    }

    public void update(View v) {

        if (mListener != null) {
            String coffeeName = name.getText().toString();
            String coffeeShop = shop.getText().toString();
            String coffeePriceStr = price.getText().toString();
            double ratingValue = ratingBar.getRating();
            double coffeePrice;

            try {
                coffeePrice = Double.parseDouble(coffeePriceStr);
            } catch (NumberFormatException e) {
                coffeePrice = 0.0;
            }

            if ((coffeeName.length() > 0) && (coffeeShop.length() > 0) && (coffeePriceStr.length() > 0)) {
                aCoffee.name = coffeeName;
                aCoffee.shop = coffeeShop;
                aCoffee.price = coffeePrice;
                aCoffee.rating = ratingValue;

                Base.app.dbManager.update(aCoffee);
                //getFragmentManager().popBackStackImmediate();

                if (getFragmentManager().getBackStackEntryCount() > 0) {
                    getFragmentManager().popBackStack();
                    return;
                }

            } else
                Toast.makeText(getActivity(),
                        "You must Enter Something for Name and Shop",
                        Toast.LENGTH_SHORT).show();
        }
    }

}
