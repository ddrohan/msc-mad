package ie.cm.fragments;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import ie.cm.R;
import ie.cm.activities.Base;
import ie.cm.adapters.CoffeeFilter;
import ie.cm.api.VolleyListener;
import ie.cm.models.Coffee;

public class SearchFragment extends CoffeeFragment
        implements AdapterView.OnItemSelectedListener, TextWatcher {

	public SearchFragment() {
		// Required empty public constructor
	}

	public static SearchFragment newInstance() {
		SearchFragment fragment = new SearchFragment();
		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
							 Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View v = null;

		v = inflater.inflate(R.layout.fragment_search, container, false);

		ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter
				.createFromResource(getActivity(), R.array.coffeeTypes,
						android.R.layout.simple_spinner_item);

		spinnerAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		Spinner spinner = ((Spinner) v.findViewById(R.id.searchCoffeeTypeSpinner));
		spinner.setAdapter(spinnerAdapter);
		spinner.setOnItemSelectedListener(this);

		EditText nameText = (EditText)v.findViewById(R.id.searchCoffeeNameEditText);
		nameText.addTextChangedListener(this);
		listView = (ListView) v.findViewById(R.id.coffeeList); //Bind to the list on our Search layout
		mSwipeRefreshLayout =   (SwipeRefreshLayout) v.findViewById(R.id.coffee_swipe_refresh_layout);
		setSwipeRefreshLayout();

		titleBar = (TextView)v.findViewById(R.id.recentAddedBarTextView);
		titleBar.setText(R.string.searchCoffeesLbl);

		return v;
	}

	@Override
	public void onStart() {
		super.onStart();
	}

	@Override
	public void onResume() {
		super.onResume();
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
		String selected = parent.getItemAtPosition(position).toString();

		if (coffeeFilter == null)
			coffeeFilter = new CoffeeFilter(Base.app.coffeeList,"all",listAdapter);

		if (selected != null) {
			if (selected.equals("All Types")) {
				coffeeFilter.setFilter("all");
			} else if (selected.equals("Favourites")) {
				coffeeFilter.setFilter("favourites");
			}
			coffeeFilter.filter("");
		}
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {

	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count, int after) {

	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		coffeeFilter.filter(s);
	}

	@Override
	public void afterTextChanged(Editable s) {}
}