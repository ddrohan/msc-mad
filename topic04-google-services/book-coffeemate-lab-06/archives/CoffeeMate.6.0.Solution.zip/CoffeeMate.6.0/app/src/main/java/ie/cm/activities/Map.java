package ie.cm.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ie.cm.R;

public class Map extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_map);
    }
}
