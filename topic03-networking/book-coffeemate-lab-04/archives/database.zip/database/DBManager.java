package ie.cm.models;

import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class DBManager {

	private SQLiteDatabase database;
	private DBDesigner dbHelper;

	public DBManager(Context context) {
		dbHelper = new DBDesigner(context);
	}

	public void open() throws SQLException {
		database = dbHelper.getWritableDatabase();
	}

	public void close() {
		database.close();
	}

	public void insert(Coffee c) {
		ContentValues values = new ContentValues();
		values.put(DBDesigner.COLUMN_NAME, c.getCoffeeName());
		values.put(DBDesigner.COLUMN_SHOP, c.getShop());
		values.put(DBDesigner.COLUMN_PRICE, c.getPrice());
		values.put(DBDesigner.COLUMN_RATING, c.getRating());
		values.put(DBDesigner.COLUMN_FAV, c.getFavourite());

		long insertId = database.insert(DBDesigner.TABLE_COFFEE, null,
				values);
	}

	public void delete(int id) {

		Log.v("DB", "Coffee deleted with id: " + id);
		database.delete(DBDesigner.TABLE_COFFEE,
				DBDesigner.COLUMN_ID + " = " + id, null);
	}

	public void update(Coffee pojo) {
		// TODO Auto-generated method stub

		ContentValues values = new ContentValues();
		values.put(DBDesigner.COLUMN_NAME, pojo.getCoffeeName());
		values.put(DBDesigner.COLUMN_SHOP, pojo.getShop());
		values.put(DBDesigner.COLUMN_PRICE, pojo.getPrice());
		values.put(DBDesigner.COLUMN_RATING, pojo.getRating());
		values.put(DBDesigner.COLUMN_FAV, pojo.getFavourite());

		long insertId = database
				.update(DBDesigner.TABLE_COFFEE,
						values,
						DBDesigner.COLUMN_ID + " = "
								+ pojo.getCoffeeId(), null);

	}

	public List<Coffee> getAll() {
		List<Coffee> coffees = new ArrayList<Coffee>();
		Cursor cursor = database.rawQuery("SELECT * FROM "
				+ DBDesigner.TABLE_COFFEE, null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Coffee pojo = toCoffee(cursor);
			coffees.add(pojo);
			cursor.moveToNext();
		}
		// Make sure to close the cursor
		cursor.close();
		return coffees;
	}

	public Coffee get(int id) {
		Coffee pojo = null;

		Cursor cursor = database.rawQuery("SELECT * FROM "
				+ DBDesigner.TABLE_COFFEE + " WHERE "
				+ DBDesigner.COLUMN_ID + " = " + id, null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Coffee temp = toCoffee(cursor);
			pojo = temp;
			cursor.moveToNext();
		}
		// Make sure to close the cursor
		cursor.close();
		return pojo;
	}

	public List<Coffee> getFavourites() {
		List<Coffee> coffees = new ArrayList<Coffee>();
		Cursor cursor = database.rawQuery("SELECT * FROM "
				+ DBDesigner.TABLE_COFFEE + " WHERE "
				+ DBDesigner.COLUMN_FAV + " = 1", null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Coffee pojo = toCoffee(cursor);
			coffees.add(pojo);
			cursor.moveToNext();
		}
		// Make sure to close the cursor
		cursor.close();
		return coffees;
	}
	
	private Coffee toCoffee(Cursor cursor) {
		Coffee pojo = new Coffee();
		pojo.setCoffeeId(cursor.getInt(0));
		pojo.setCoffeeName(cursor.getString(1));
		pojo.setShop(cursor.getString(2));
		pojo.setPrice(cursor.getDouble(3));
		pojo.setRating(cursor.getDouble(4));
		pojo.setFavourite(cursor.getInt(5));

		return pojo;
	}

	public void setupList() {
		Coffee c1 = new Coffee("Mocca Latte", "Ardkeen Stores", 4, 2.99, 0);
		Coffee c2 = new Coffee("Espresso", "Tescos Stores",3.5, 1.99, 1);
		Coffee c3 = new Coffee("Standard Black", "Ardkeen Stores",2.5, 1.99, 1);
		Coffee c4 = new Coffee("Cappuccino", "Spar Shop",2.5, 1.49, 0);

		insert(c1);
		insert(c2);
		insert(c3);
		insert(c4);
	}
}
