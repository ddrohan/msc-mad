package ie.cm.activities;

import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.plus.PlusShare;

import java.util.List;

import ie.cm.R;
import ie.cm.api.CoffeeApi;
import ie.cm.api.VolleyListener;
import ie.cm.fragments.AddFragment;
import ie.cm.fragments.CoffeeFragment;
import ie.cm.fragments.EditFragment;
import ie.cm.fragments.EditFragment.OnFragmentInteractionListener;
import ie.cm.fragments.HelpFragment;
import ie.cm.fragments.MapsFragment;
import ie.cm.fragments.SearchFragment;
import ie.cm.main.CoffeeMateApp;
import ie.cm.models.Coffee;

public class Home extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        OnFragmentInteractionListener,
        GoogleApiClient.OnConnectionFailedListener {

    private ImageView googlePhoto;
    public CoffeeMateApp app = CoffeeMateApp.getInstance();

    private static final String TAG = "coffeemate";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Information", Snackbar.LENGTH_LONG)
                        .setAction("More Info...", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                openInfoDialog(Home.this);
                            }
                        }).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //SetUp GooglePhoto and Email for Drawer here
        googlePhoto = (ImageView)navigationView.getHeaderView(0).findViewById(R.id.googlephoto);
        CoffeeApi.getGooglePhoto(app.googlePhotoURL,googlePhoto);

        TextView googleName = (TextView)navigationView.getHeaderView(0).findViewById(R.id.googlename);
        googleName.setText(app.googleName);

        TextView googleMail = (TextView)navigationView.getHeaderView(0).findViewById(R.id.googlemail);
        googleMail.setText(app.googleMail);

        app.dialog = new ProgressDialog(this,1);

        FragmentTransaction ft = getFragmentManager().beginTransaction();

        CoffeeFragment fragment = CoffeeFragment.newInstance();
        ft.replace(R.id.homeFrame, fragment);
        ft.commit();
    }


    @Override
    public void onStart() {
        super.onStart();
        if(!app.mGoogleApiClient.isConnected())
            app.mGoogleApiClient.connect();

        Log.v(TAG, "Google Client Connected onStart() HOME Screen : " + (app.mGoogleApiClient.isConnected() ? "YES" : "NO") + " " + app.mGoogleApiClient);
    }

    @Override
    public void onResume()
    {
        super.onResume();
        if(!app.mGoogleApiClient.isConnected())
            app.mGoogleApiClient.connect();

        Log.v(TAG, "Google Client Connected onResume() HOME Screen : " + (app.mGoogleApiClient.isConnected() ? "YES" : "NO") + " " + app.mGoogleApiClient);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (app.mGoogleApiClient != null && app.mGoogleApiClient.isConnected())
            app.mGoogleApiClient.disconnect();

        Log.v(TAG, "Google Client Connected onDestroy() HOME Screen : " + (app.mGoogleApiClient.isConnected() ? "YES" : "NO") + " " + app.mGoogleApiClient);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    public void menuInfo(MenuItem m)
    {
        openInfoDialog(this);
    }

    public void menuHelp(MenuItem m)
    {
        FragmentTransaction ft = getFragmentManager().beginTransaction();

        HelpFragment fragment = HelpFragment.newInstance();
        ft.replace(R.id.homeFrame, fragment);
        ft.addToBackStack(null);
        ft.commit();
    }

    public void menuHome(MenuItem m)
    {
        startActivity(new Intent(this, Home.class));
    }

    public void menuLogout(MenuItem item) {

        if(!app.mGoogleApiClient.isConnected())
            app.mGoogleApiClient.connect();
        else {

            Auth.GoogleSignInApi.signOut(app.mGoogleApiClient).setResultCallback(
                    new ResultCallback<Status>() {
                        @Override
                        public void onResult(Status status) {
                            //revokeAccess();
                            // [START_EXCLUDE]
                            startActivity(new Intent(Home.this, Login.class)
                                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                            Log.v("coffeemate", "CoffeeMate User Logged Out");
                            //Home.this.finish();
                            // [END_EXCLUDE]
                        }
                    });
        }
        Log.v(TAG, "Google Client Connected on menuLogout() HOME Screen: " + (app.mGoogleApiClient.isConnected() ? "YES" : "NO") + app.mGoogleApiClient);
    }

    private void revokeAccess() {
        Auth.GoogleSignInApi.revokeAccess(app.mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(Status status) {
                    }
                });
    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        // http://stackoverflow.com/questions/32944798/switch-between-fragments-with-onnavigationitemselected-in-new-navigation-drawer
        int id = item.getItemId();
        Fragment fragment;
        FragmentTransaction ft = getFragmentManager().beginTransaction();

        if (id == R.id.nav_home) {
            fragment = CoffeeFragment.newInstance();
            ((CoffeeFragment)fragment).favourites = false;
            ft.replace(R.id.homeFrame, fragment);
            ft.addToBackStack(null);
            ft.commit();

        } else if (id == R.id.nav_add) {
            fragment = AddFragment.newInstance();
            ft.replace(R.id.homeFrame, fragment);
            ft.addToBackStack(null);
            ft.commit();

        } else if (id == R.id.nav_favourites) {
            fragment = CoffeeFragment.newInstance();
            ((CoffeeFragment)fragment).favourites = true;
            ft.replace(R.id.homeFrame, fragment);
            ft.addToBackStack(null);
            ft.commit();

        } else if (id == R.id.nav_search) {
            fragment = SearchFragment.newInstance();
            ((SearchFragment)fragment).favourites = false;
            ft.replace(R.id.homeFrame, fragment);
            ft.addToBackStack(null);
            ft.commit();

        } else if (id == R.id.nav_share) {

                // Launch the Google+ share dialog with attribution to your app.
                Intent shareIntent = new PlusShare.Builder(this).setType("text/plain")
                        .setText("Google+ Demo http://ddrohan.gitbooks.io")
                        .setContentUrl(Uri.parse("http://ddrohan.gitbooks.io")).getIntent();

                startActivityForResult(shareIntent, 0);

        } else if (id == R.id.nav_camera) {

        }
          else if (id == R.id.nav_map) {
            //startActivity(new Intent(this, Map.class));
            fragment = MapsFragment.newInstance();
            ft.replace(R.id.homeFrame, fragment);
            ft.addToBackStack(null);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }



    @Override
    public void toggle(View v) {
        EditFragment editFrag = (EditFragment)
                getFragmentManager().findFragmentById(R.id.homeFrame);

        if (editFrag != null) {
            editFrag.toggle(v);
        }
    }

    @Override
    public void update(View v) {
        EditFragment editFrag = (EditFragment)
                getFragmentManager().findFragmentById(R.id.homeFrame);

        if (editFrag != null) {
            editFrag.update(v);
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.v("coffeemate", "Connection Failed Error in Home....");
    }

    public void openInfoDialog(Activity current) {
        Dialog dialog = new Dialog(current);
        dialog.setTitle("About CoffeeMate");
        dialog.setContentView(R.layout.info);

        TextView currentVersion = (TextView) dialog
                .findViewById(R.id.versionTextView);
        currentVersion.setText("6.0.1");

        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();
    }
}
