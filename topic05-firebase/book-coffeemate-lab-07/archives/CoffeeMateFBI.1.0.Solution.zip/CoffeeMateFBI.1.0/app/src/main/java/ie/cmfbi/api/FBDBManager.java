package ie.cmfbi.api;

import android.util.Log;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ie.cmfbi.models.Coffee;
import ie.cmfbi.models.User;

public class FBDBManager {

    private static final String TAG = "coffeemate";
    public DatabaseReference mFirebaseDatabase;
    public static String mFBUserId;
    public FBDBListener mFBDBListener;


    public void open() {
        //Set up local caching
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        //Bind to remote Firebase Database
        mFirebaseDatabase = FirebaseDatabase.getInstance().getReference();
        Log.v(TAG, "Database Connected :" + mFirebaseDatabase);
    }

    public void attachListener(FBDBListener listener) {
        mFBDBListener = listener;
    }

    //Check to see if the Firebase User exists in the Database
    //if not, create a new User
    public void checkUser(final String userid,final String username,final String email) {
        Log.v(TAG, "checkUser ID == " + userid);
        mFirebaseDatabase.child("users").child(userid).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        mFBDBListener.onSuccess(dataSnapshot);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        mFBDBListener.onFailure();
                    }
                }
        );
    }

    public void addCoffee(final Coffee c)
    {
        mFirebaseDatabase.child("users").child(mFBUserId).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        // Get user value
                        User user = dataSnapshot.getValue(User.class);

                        if (user == null) {
                            // User is null, error out
                            Log.v(TAG, "User " + mFBUserId + " is unexpectedly null");
                            //Toast.makeText(this,
                            //		"Error: could not fetch user.",
                            //		Toast.LENGTH_SHORT).show();
                        } else {
                            // Write new coffee
                            writeNewCoffee(c);
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.v(TAG, "getUser:onCancelled", databaseError.toException());
                    }
                });
    }

    private void writeNewCoffee(Coffee c) {
        // Create new coffee at /user-coffees/$userid/$coffeeid and at
        // /coffees/$coffeeid simultaneously
        String key = mFirebaseDatabase.child("coffees").push().getKey();
        Map<String, Object> coffeeValues = c.toMap();

        Map<String, Object> childUpdates = new HashMap<>();
        //All our coffees
        childUpdates.put("/coffees/" + key, coffeeValues);
        //All coffees per user
        childUpdates.put("/user-coffees/" + mFBUserId + "/" + key, coffeeValues);

        mFirebaseDatabase.updateChildren(childUpdates);
    }

    public Query getAllCoffees()
    {
        Query query = mFirebaseDatabase.child("user-coffees").child(mFBUserId)
                .orderByChild("rating");

        return query;
    }

    public Query getFavouriteCoffees()
    {
        Query query = mFirebaseDatabase.child("user-coffees").child(mFBUserId)
                .orderByChild("favourite").equalTo(true);

        return query;
    }

    public void getACoffee(final String coffeeKey)
    {
        mFirebaseDatabase.child("user-coffees").child(mFBUserId).child(coffeeKey).addValueEventListener(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Log.v(TAG,"The read Succeeded: " + dataSnapshot.toString());
                        mFBDBListener.onSuccess(dataSnapshot);
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.v(TAG,"The read failed: " + firebaseError.getMessage());
                        mFBDBListener.onFailure();
                    }
                });
    }

    public void updateACoffee(final String coffeeKey,final Coffee updatedCoffee)
    {
        mFirebaseDatabase.child("user-coffees").child(mFBUserId).child(coffeeKey).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Log.v(TAG,"The update Succeeded: " + dataSnapshot.toString());
                        dataSnapshot.getRef().setValue(updatedCoffee);
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.v(TAG,"The update failed: " + firebaseError.getMessage());
                        mFBDBListener.onFailure();
                    }
                });
    }

    public void toggleFavourite(final String coffeeKey,final boolean isFavourite)
    {
        mFirebaseDatabase.child("user-coffees").child(mFBUserId).child(coffeeKey).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        snapshot.getRef().child("favourite").setValue(isFavourite);
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.v(TAG,"The toggle failed: " + firebaseError.getMessage());
                    }
                });
    }

    public void deleteACoffee(final String coffeeKey)
    {
        mFirebaseDatabase.child("user-coffees").child(mFBUserId).child(coffeeKey).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        snapshot.getRef().removeValue();
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.v(TAG,"The delete failed: " + firebaseError.getMessage());
                    }
                });
    }

    public Query nameFilter(String s)
    {
        Query query = mFirebaseDatabase.child("user-coffees").child(mFBUserId)
                .orderByChild("name").startAt(s).endAt(s+"\uf8ff");

        return query;
    }

    public void getAllCoffeesSnapshot()
    {
        ValueEventListener vel = mFirebaseDatabase.child("user-coffees")
                                            .child(mFBUserId)
                                            .addValueEventListener(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        mFBDBListener.onSuccess(dataSnapshot);
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        mFBDBListener.onFailure();
                    }
                });
    }

    //	public void addChangeListener(String userId)
//	{
//
//		Query allCoffeesQuery = fbDatabase.child("user-coffees").child(userId)
//				.orderByChild("rating");
//
//
//
//		allCoffeesQuery.addChildEventListener(new ChildEventListener() {
//			// TODO: implement the ChildEventListener methods as documented
//
//			@Override
//			public void onChildAdded(DataSnapshot dataSnapshot, String previousChildName) {
//				Log.d(TAG, "onChildAdded:" + dataSnapshot.getKey());
//
//				// A new comment has been added, add it to the displayed list
//				 Coffee c = dataSnapshot.getValue(Coffee.class);
//				 FBDManager.coffeeList.add(c);
//				//HashMap<String, Object> result = (HashMap<String, Object>)dataSnapshot.getValue();
//				Log.d(TAG, "dataSnapShop is :" + dataSnapshot);
//				Log.d(TAG, "coffeeList is now :" + FBDManager.coffeeList);
//
//				// ...
//			}
//
//			@Override
//			public void onChildChanged(DataSnapshot dataSnapshot, String previousChildName) {
//				Log.d(TAG, "onChildChanged:" + dataSnapshot.getKey());
//
//				// A comment has changed, use the key to determine if we are displaying this
//				// comment and if so displayed the changed comment.
//				Coffee c = dataSnapshot.getValue(Coffee.class);
//				String coffeeKey = dataSnapshot.getKey();
//
//				// ...
//			}
//
//			@Override
//			public void onChildMoved(DataSnapshot dataSnapshot, String previousChildName) {
//				Log.d(TAG, "onChildMoved:" + dataSnapshot.getKey());
//
//				// A comment has changed position, use the key to determine if we are
//				// displaying this comment and if so move it.
//				Coffee c = dataSnapshot.getValue(Coffee.class);
//				String coffeeKey = dataSnapshot.getKey();
//
//				// ...
//			}
//
//			@Override
//			public void onChildRemoved(DataSnapshot dataSnapshot) {
//				Log.d(TAG, "onChildRemoved:" + dataSnapshot.getKey());
//
//				// A comment has changed, use the key to determine if we are displaying this
//				// comment and if so remove it.
//				String commentKey = dataSnapshot.getKey();
//
//				// ...
//			}
//
//			@Override
//			public void onCancelled(DatabaseError databaseError) {
//				Log.w(TAG, "loadCoffees:onCancelled", databaseError.toException());
//				//Toast.makeText(mContext, "Failed to load coffees.",
//				//		Toast.LENGTH_SHORT).show();
//			}
//		});
//	}
}
