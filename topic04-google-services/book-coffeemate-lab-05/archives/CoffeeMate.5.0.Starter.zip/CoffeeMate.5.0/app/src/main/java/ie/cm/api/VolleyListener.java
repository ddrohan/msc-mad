package ie.cm.api;

import android.app.Fragment;

import java.util.List;

/**
 * Created by ddrohan on 19/07/2016.
 */
public interface VolleyListener {
    void setList(List list);
    void updateUI(Fragment fragment);
}
