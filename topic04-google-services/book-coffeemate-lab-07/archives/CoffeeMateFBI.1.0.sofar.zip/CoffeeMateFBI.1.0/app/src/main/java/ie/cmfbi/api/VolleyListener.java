package ie.cmfbi.api;

import java.util.List;
import ie.cmfbi.models.Coffee;

public interface VolleyListener {
    void setList(List list);
    void setCoffee(Coffee c);
}
